-- CLEVELAND CLINICS OHIO
-- PROJECT SQL QUERIES
-- 1.VIEW ALL PATIENTS
select *
from patients;

-- 2. TOTAL NUMBER OF PATIENTS
SELECT COUNT(*) AS total_patients
FROM patients;

-- 3. TOTAL NUMBER OF APPOINTMENTS
SELECT COUNT(*) AS total_appointments
FROM appointments;

-- 4. PATIENT VISITS BY DATE
-- Shows the number of visits and unique patients each day
SELECT
    date_of_consultation,
    COUNT(*) AS total_visits,
    COUNT(DISTINCT patient_id) AS unique_patients
FROM appointments
GROUP BY date_of_consultation
ORDER BY date_of_consultation;


-- ============================================================
-- 5. COMMON DIAGNOSES
-- Shows diagnoses from most common to least common
-- ============================================================

SELECT
    diagnosis,
    COUNT(*) AS diagnosis_count
FROM appointments
WHERE diagnosis IS NOT NULL
  AND TRIM(diagnosis) <> ''
GROUP BY diagnosis
ORDER BY diagnosis_count DESC;


-- 6. TOTAL REVENUE
SELECT
    SUM(total_bill) AS total_revenue
FROM billing;

-- 7. TOTAL INSURANCE COVERAGE
SELECT
    SUM(amount_covered) AS total_insurance_covered
FROM billing;

-- 8. TOTAL PATIENT PAYMENT
SELECT
    SUM(out_of_pocket_expenses) AS total_patient_paid
FROM billing;

-- 9. REVENUE BY CONSULTATION DATE
-- Billing does not contain a date.
-- Therefore, we connect billing with appointments using case_id.
SELECT
    a.date_of_consultation,
    COUNT(b.claim_id) AS total_claims,
    SUM(b.total_bill) AS total_revenue,
    SUM(b.amount_covered) AS insurance_covered,
    SUM(b.out_of_pocket_expenses) AS patient_paid
FROM billing b
JOIN appointments a
    ON b.case_id = a.case_id
GROUP BY a.date_of_consultation
ORDER BY a.date_of_consultation;

-- 10. PATIENTS WHO HAD SURGERY
SELECT
    patient_id,
    surgery_underwent
FROM patients
WHERE LOWER(surgery_underwent) = 'yes';

-- 11. NUMBER OF SURGERIES BY SURGERY TYPE
SELECT
    surgery_type,
    COUNT(*) AS total_surgeries
FROM surgeries
GROUP BY surgery_type
ORDER BY total_surgeries DESC;

-- 12. SURGERY OUTCOMES
SELECT
    surgery_outcome,
    COUNT(*) AS outcome_count
FROM surgeries
GROUP BY surgery_outcome
ORDER BY outcome_count DESC;

-- 13. APPOINTMENTS BY BRANCH
SELECT
    branch_id,
    COUNT(*) AS total_appointments
FROM appointments
GROUP BY branch_id
ORDER BY total_appointments DESC;

-- 14. APPOINTMENTS BY DOCTOR
SELECT
    consulted_doctor_id,
    COUNT(*) AS total_appointments
FROM appointments
GROUP BY consulted_doctor_id
ORDER BY total_appointments DESC;

-- 15. DOCTORS BY SPECIALIZATION
SELECT
    specialization,
    COUNT(*) AS doctor_count
FROM doctors
GROUP BY specialization
ORDER BY doctor_count DESC;

-- 16. BILLING BY CLAIM STATUS
SELECT
    claim_status,
    COUNT(*) AS claim_count,
    SUM(total_bill) AS total_bill
FROM billing
GROUP BY claim_status
ORDER BY claim_count DESC;

-- 17. PATIENT SATISFACTION
SELECT
    ROUND(AVG(overall_satisfaction_rating), 2)
        AS average_satisfaction_rating
FROM patients;

-- 18. PATIENTS WITH MORE THAN 5 VISITS
SELECT
    patient_id,
    total_number_of_visits
FROM patients
WHERE total_number_of_visits > 5
ORDER BY total_number_of_visits DESC;

-- 19. LAB TESTS BY TEST NAME
SELECT
    test_name,
    COUNT(*) AS test_count
FROM lab_reports
GROUP BY test_name
ORDER BY test_count DESC;

-- 20. PRESCRIPTIONS BY MEDICATION
SELECT
    medication_name,
    COUNT(*) AS prescription_count
FROM prescriptions
GROUP BY medication_name
ORDER BY prescription_count DESC;