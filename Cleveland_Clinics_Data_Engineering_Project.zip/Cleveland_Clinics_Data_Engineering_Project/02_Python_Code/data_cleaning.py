import pandas as pd


# --------------------------------------------------
# 1. Load the Cleveland Clinics CSV files
# --------------------------------------------------

patients = pd.read_csv("patients.csv")
doctors = pd.read_csv("doctors.csv")
branches = pd.read_csv("branches.csv")
appointments = pd.read_csv("appointments.csv")
billing = pd.read_csv("billing.csv")
lab_reports = pd.read_csv("lab_reports.csv")
prescriptions = pd.read_csv("prescriptions.csv")
surgeries = pd.read_csv("surgeries.csv")


# --------------------------------------------------
# 2. Rename columns into clean snake_case names
# --------------------------------------------------

patients.columns = [
    "sl_no",
    "patient_id",
    "date_of_registration",
    "date_of_first_consultation",
    "date_of_latest_consultation",
    "overall_satisfaction_rating",
    "admission",
    "surgery_underwent",
    "total_number_of_visits"
]

doctors.columns = [
    "sl_no",
    "doctor_name",
    "doctor_id",
    "specialization",
    "qualification",
    "surgery_experience",
    "practicing_branch",
    "other_branches_visited"
]

branches.columns = [
    "sl_no",
    "branch_id",
    "location",
    "ot_available",
    "inhouse_anesthetian",
    "no_of_ots",
    "inhouse_pharmacy",
    "inhouse_nutritionist",
    "inpatient_rooms",
    "luxury_suite_rooms",
    "prayer_room",
    "kids_play_area"
]

appointments.columns = [
    "serial_no",
    "case_id",
    "patient_id",
    "branch_id",
    "date_of_consultation",
    "requested_doctor_id",
    "consulted_doctor_id",
    "reason_for_visit",
    "diagnosis",
    "prescribed_medication",
    "followup_required",
    "nutritionist_recommended"
]

billing.columns = [
    "serial_no",
    "claim_id",
    "patient_id",
    "case_id",
    "branch_id",
    "total_bill",
    "insurance_provider",
    "amount_covered",
    "out_of_pocket_expenses",
    "claim_status"
]

lab_reports.columns = [
    "serial_no",
    "report_id",
    "case_id",
    "patient_id",
    "branch_id",
    "test_name",
    "test_date",
    "result"
]

prescriptions.columns = [
    "serial_no",
    "bill_id",
    "patient_id",
    "doctor_id",
    "medication_name",
    "dosage",
    "quantity",
    "pharmacy_availability",
    "issued_date"
]

surgeries.columns = [
    "serial_no",
    "case_id",
    "patient_id",
    "doctor_id",
    "branch_id",
    "surgery_type",
    "surgery_date",
    "anesthesia_type",
    "surgery_outcome",
    "surgery_duration_hours",
    "recovery_period_days"
]


# --------------------------------------------------
# 3. Convert date columns
# --------------------------------------------------

patients["date_of_registration"] = pd.to_datetime(
    patients["date_of_registration"], errors="coerce"
)

patients["date_of_first_consultation"] = pd.to_datetime(
    patients["date_of_first_consultation"], errors="coerce"
)

patients["date_of_latest_consultation"] = pd.to_datetime(
    patients["date_of_latest_consultation"], errors="coerce"
)

appointments["date_of_consultation"] = pd.to_datetime(
    appointments["date_of_consultation"], errors="coerce"
)

lab_reports["test_date"] = pd.to_datetime(
    lab_reports["test_date"], errors="coerce"
)

prescriptions["issued_date"] = pd.to_datetime(
    prescriptions["issued_date"], errors="coerce"
)

surgeries["surgery_date"] = pd.to_datetime(
    surgeries["surgery_date"], errors="coerce"
)


# --------------------------------------------------
# 4. Convert numeric columns
# --------------------------------------------------

patients["overall_satisfaction_rating"] = pd.to_numeric(
    patients["overall_satisfaction_rating"], errors="coerce"
)

patients["total_number_of_visits"] = pd.to_numeric(
    patients["total_number_of_visits"], errors="coerce"
)

billing["total_bill"] = pd.to_numeric(
    billing["total_bill"], errors="coerce"
)

billing["amount_covered"] = pd.to_numeric(
    billing["amount_covered"], errors="coerce"
)

billing["out_of_pocket_expenses"] = pd.to_numeric(
    billing["out_of_pocket_expenses"], errors="coerce"
)

prescriptions["quantity"] = pd.to_numeric(
    prescriptions["quantity"], errors="coerce"
)

surgeries["surgery_duration_hours"] = pd.to_numeric(
    surgeries["surgery_duration_hours"], errors="coerce"
)

surgeries["recovery_period_days"] = pd.to_numeric(
    surgeries["recovery_period_days"], errors="coerce"
)


# --------------------------------------------------
# 5. Store all tables in a dictionary
# --------------------------------------------------

tables = {
    "patients": patients,
    "doctors": doctors,
    "branches": branches,
    "appointments": appointments,
    "billing": billing,
    "lab_reports": lab_reports,
    "prescriptions": prescriptions,
    "surgeries": surgeries
}


# --------------------------------------------------
# 6. Remove duplicate rows
# --------------------------------------------------

for name, df in tables.items():
    before = len(df)

    df.drop_duplicates(inplace=True)

    after = len(df)

    print(
        f"{name}: {before - after} duplicate rows removed"
    )


# --------------------------------------------------
# 7. Clean text columns
# --------------------------------------------------

for name, df in tables.items():

    for column in df.select_dtypes(include="object").columns:

        df[column] = (
            df[column]
            .astype(str)
            .str.strip()
        )


# --------------------------------------------------
# 8. Standardize Yes/No columns
# --------------------------------------------------

yes_no_columns = {

    "patients": [
        "admission",
        "surgery_underwent"
    ],

    "branches": [
        "ot_available",
        "inhouse_anesthetian",
        "inhouse_pharmacy",
        "inhouse_nutritionist",
        "prayer_room",
        "kids_play_area"
    ],

    "appointments": [
        "followup_required",
        "nutritionist_recommended"
    ],

    "prescriptions": [
        "pharmacy_availability"
    ]
}


for table_name, columns in yes_no_columns.items():

    df = tables[table_name]

    for column in columns:

        if column in df.columns:

            df[column] = (
                df[column]
                .str.strip()
                .str.lower()
                .replace({
                    "yes": "Yes",
                    "no": "No"
                })
            )


# --------------------------------------------------
# 9. Create cleaned copies
# --------------------------------------------------

patients_clean = patients.copy()
doctors_clean = doctors.copy()
branches_clean = branches.copy()
appointments_clean = appointments.copy()
billing_clean = billing.copy()
lab_reports_clean = lab_reports.copy()
prescriptions_clean = prescriptions.copy()
surgeries_clean = surgeries.copy()


# --------------------------------------------------
# 10. Save cleaned CSV files
# --------------------------------------------------

patients_clean.to_csv(
    "patients_clean.csv",
    index=False
)

doctors_clean.to_csv(
    "doctors_clean.csv",
    index=False
)

branches_clean.to_csv(
    "branches_clean.csv",
    index=False
)

appointments_clean.to_csv(
    "appointments_clean.csv",
    index=False
)

billing_clean.to_csv(
    "billing_clean.csv",
    index=False
)

lab_reports_clean.to_csv(
    "lab_reports_clean.csv",
    index=False
)

prescriptions_clean.to_csv(
    "prescriptions_clean.csv",
    index=False
)

surgeries_clean.to_csv(
    "surgeries_clean.csv",
    index=False
)


# --------------------------------------------------
# 11. Final quality check
# --------------------------------------------------

print("\n========== DATA QUALITY CHECK ==========")

for name, df in tables.items():

    print(f"\n{name.upper()}")

    print("Rows:", len(df))
    print("Columns:", len(df.columns))
    print("Missing values:", df.isnull().sum().sum())
    print("Duplicate rows:", df.duplicated().sum())


print("\n✅ Data cleaning and transformation completed successfully.")
print("✅ Cleaned CSV files created successfully.")