# Import required libraries
import pandas as pd
import psycopg2

# Connect to PostgreSQL
connection = psycopg2.connect(
    host="cleveland-clinics-db.cjci464um6gf.eu-north-1.rds.amazonaws.com",
    port=5432,
    database="postgres",
    user="postgresadmin",
    password="YOUR_RDS_PASSWORD"
)

# Generate patient visits report
query_patient_visits = """
SELECT
    date_of_consultation,
    COUNT(*) AS total_visits,
    COUNT(DISTINCT patient_id) AS unique_patients
FROM appointments
GROUP BY date_of_consultation
ORDER BY date_of_consultation;
"""

patient_visits_report = pd.read_sql(
    query_patient_visits,
    connection
)

# Generate revenue report
query_revenue = """
SELECT
    COUNT(DISTINCT claim_id) AS total_claims,
    SUM(total_bill) AS total_revenue,
    SUM(amount_covered) AS insurance_covered,
    SUM(out_of_pocket_expenses) AS patient_paid
FROM billing;
"""

revenue_report = pd.read_sql(
    query_revenue,
    connection
)

# Generate common diagnoses report
query_diagnoses = """
SELECT
    diagnosis,
    COUNT(*) AS diagnosis_count
FROM appointments
WHERE diagnosis IS NOT NULL
  AND TRIM(diagnosis) <> ''
GROUP BY diagnosis
ORDER BY diagnosis_count DESC;
"""

diagnoses_report = pd.read_sql(
    query_diagnoses,
    connection
)

# Save reports as CSV files
patient_visits_report.to_csv(
    "patient_visits_report.csv",
    index=False
)

revenue_report.to_csv(
    "revenue_report.csv",
    index=False
)

diagnoses_report.to_csv(
    "common_diagnoses_report.csv",
    index=False
)

# Close database connection
connection.close()

# Display completion message
print("Patient visits report created successfully.")
print("Revenue report created successfully.")
print("Common diagnoses report created successfully.")
print("Daily reports generated successfully.")