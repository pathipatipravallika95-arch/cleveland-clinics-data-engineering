# AWS Lambda function for the Cleveland Clinics daily reporting pipeline

import csv
import io
import os

import boto3
import pg8000


# S3 bucket and report folder
S3_BUCKET = "cleveland-clinics-etl-2026-pravallika"
S3_FOLDER = "reports/"

s3 = boto3.client("s3")


def lambda_handler(event, context):

    # Connect to RDS PostgreSQL using Lambda environment variables
    connection = pg8000.connect(
        host=os.environ["RDS_HOST"],
        port=int(os.environ["RDS_PORT"]),
        database=os.environ["RDS_DATABASE"],
        user=os.environ["RDS_USER"],
        password=os.environ["RDS_PASSWORD"]
    )

    print("Connected to RDS PostgreSQL")

    cursor = connection.cursor()

    # Generate patient visits report
    patient_visits_query = """
    SELECT
        date_of_consultation,
        COUNT(*) AS total_visits,
        COUNT(DISTINCT patient_id) AS unique_patients
    FROM appointments
    GROUP BY date_of_consultation
    ORDER BY date_of_consultation;
    """

    cursor.execute(patient_visits_query)

    patient_columns = [column[0] for column in cursor.description]
    patient_data = cursor.fetchall()

    # Generate revenue report
    # Billing data does not contain a billing date,
    # so the report provides the overall revenue total.
    revenue_query = """
    SELECT
        'ALL' AS date_of_consultation,
        COUNT(DISTINCT claim_id) AS total_claims,
        ROUND(SUM(total_bill), 2) AS total_revenue,
        ROUND(SUM(amount_covered), 2) AS insurance_covered,
        ROUND(SUM(out_of_pocket_expenses), 2) AS patient_paid
    FROM billing;
    """

    cursor.execute(revenue_query)

    revenue_columns = [column[0] for column in cursor.description]
    revenue_data = cursor.fetchall()

    # Generate common diagnoses report
    diagnoses_query = """
    SELECT
        diagnosis,
        COUNT(*) AS diagnosis_count
    FROM appointments
    WHERE diagnosis IS NOT NULL
      AND TRIM(diagnosis) <> ''
    GROUP BY diagnosis
    ORDER BY diagnosis_count DESC;
    """

    cursor.execute(diagnoses_query)

    diagnoses_columns = [column[0] for column in cursor.description]
    diagnoses_data = cursor.fetchall()

    # Close database connection
    cursor.close()
    connection.close()

    # Upload a report to S3
    def upload_report(filename, columns, data):

        output = io.StringIO()

        writer = csv.writer(output)

        writer.writerow(columns)
        writer.writerows(data)

        s3.put_object(
            Bucket=S3_BUCKET,
            Key=S3_FOLDER + filename,
            Body=output.getvalue(),
            ContentType="text/csv"
        )

        print("Uploaded:", filename)

    # Upload patient visits report
    upload_report(
        "patient_visits_report.csv",
        patient_columns,
        patient_data
    )

    # Upload revenue report
    upload_report(
        "revenue_report.csv",
        revenue_columns,
        revenue_data
    )

    # Upload common diagnoses report
    upload_report(
        "common_diagnoses_report.csv",
        diagnoses_columns,
        diagnoses_data
    )

    # Return successful response
    return {
        "statusCode": 200,
        "body": "Daily reports generated and uploaded to S3 successfully."
    }